<?php

namespace App\Http\Controllers;

use App\Events\UserRegistered;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\User;

class AuthController extends Controller
{
    public function login(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
            'password' => 'required',
        ]);

        if (!Auth::attempt($request->only('email', 'password'))) {
            return response()->json(['message' => 'Invalid credentials'], 401);
        }

        $user = Auth::user();
        $token = $user->createToken('auth_token')->plainTextToken;

        return response()->json([
            'token' => $token,
            'token_type' => 'Bearer',
        ]);
    }

    public function register(Request $request)
    {
        // Validate the incoming request data
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|min:8|confirmed',
        ]);

        // Create a new user instance and hash the password
        $user =  User::create([
            'name' => $request['name'],
            'family' => $request['family'],
            'phone' => $request['phone'],
            'email' => $request['email'],
            'password' => Hash::make($request['password']),
        ]);

        // Log the user in and create an authentication token
        $token = $user->createToken('auth_token')->plainTextToken;
        event(new UserRegistered($user));

        // Return the token and a success message
        return response()->json([
            'token' => $token,
            'token_type' => 'Bearer',
            'message' => 'User registered successfully!',
        ]);

    }

    public function user(Request $request)
    {
        $user = Auth::user();
        return response()->json($user);
    }
}

